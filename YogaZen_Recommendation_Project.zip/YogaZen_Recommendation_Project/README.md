# YogaZen Hybrid Recommendation System

## Included data
- `data/customers.csv`: 1,000 synthetic customer profiles.
- `data/products.csv`: 120 synthetic YogaZen-style products in 12 categories.
- `data/interactions_1000_customers.csv`: aggregated user-product interactions in the column format from the handover specification.
- `data/event_weights.json`: event weights from the specification.
- `models/yogazen_hybrid_model.joblib`: trained hybrid model bundle.
- `outputs/top6_recommendations_per_customer.csv`: top 6 recommendations for each of the 1,000 customers.
- `outputs/evaluation_metrics.json`: offline holdout evaluation.

## Model
Hybrid recommender:
- 65% collaborative signal using TruncatedSVD matrix factorization over the user-item interaction matrix.
- 35% content signal using TF-IDF product title/category/description similarity.
- Recommendations exclude products already seen in the training history.
- For a known customer, the API uses the trained customer profile.
- For an unknown/guest session, the API uses recent interactions; with no history, it falls back to interaction popularity.

This is a practical baseline implementation. The handover specification lists ALS/LightFM/GRU4Rec as candidate approaches; this project uses scikit-learn TruncatedSVD plus TF-IDF to keep training reproducible with common Python packages.

## Dataset scale
- Customers: 1000
- Products: 120
- Aggregated user-product rows: 39687
- Average interactions per customer: 39.7

## Run locally
Python 3.10+ recommended.

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Retrain the model
python train_model.py

# 4. Start the API
uvicorn app:app --reload --host 127.0.0.1 --port 8000

# 5. Open API docs
# http://127.0.0.1:8000/docs
```

## Example request
```json
{
  "user_context": {
    "user_id": "usr_0001",
    "session_id": "ses_demo_001",
    "is_guest": false
  },
  "recent_interactions": [
    {
      "product_id": "prod_0001",
      "product_title": "Tibetan Singing Bowl",
      "category": "Sound Healing",
      "event_type": "product_view",
      "dwell_time_seconds": 28,
      "price": 2899
    }
  ],
  "user_affinities": {
    "top_categories": [
      {"category": "Sound Healing", "interaction_count": 8, "weight": 14.5}
    ],
    "average_budget_range": {
      "min_viewed_price": 649,
      "max_viewed_price": 2899,
      "average_price": 1682
    }
  },
  "current_state": {
    "cart_items": [],
    "wishlist_items": []
  },
  "limit": 6
}
```

## Important notes before production
1. All customer, product and interaction records in this package are synthetic, not real YogaZen telemetry.
2. Offline metrics are measured on a synthetic holdout split and should not be presented as expected production performance.
3. Replace the synthetic CSV with the backend export before real deployment. Confirm product IDs match MongoDB IDs and ensure product catalogue metadata is exported consistently.
4. The current synthetic training script expects a matching `products.csv`. For real data, export a product catalogue with `product_id`, `product_title`, `category`, and optionally `description`.
5. The API returns product IDs and scores. YogaZen backend should hydrate product cards from MongoDB, as described in the handover.
6. The baseline API does not yet apply price-budget constraints or category-diversity reranking. Those can be added after confirming desired business rules.
