"""
YogaZen recommendation API.
Run from project folder:
  uvicorn app:app --host 0.0.0.0 --port 8000
"""
from pathlib import Path
from typing import Optional, List, Dict, Any
import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "yogazen_hybrid_model.joblib"
if not MODEL_PATH.exists():
    raise RuntimeError("Model file not found. Run: python train_model.py")
model = joblib.load(MODEL_PATH)
app = FastAPI(title="YogaZen Recommendation API", version="1.0.0")

class Interaction(BaseModel):
    product_id: str
    product_title: Optional[str] = None
    category: Optional[str] = None
    event_type: Optional[str] = "product_view"
    dwell_time_seconds: Optional[float] = 0
    variety_sku: Optional[str] = None
    price: Optional[float] = None

class UserContext(BaseModel):
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    is_guest: bool = False

class PredictRequest(BaseModel):
    user_context: UserContext
    recent_interactions: List[Interaction] = Field(default_factory=list)
    user_affinities: Optional[Dict[str, Any]] = None
    current_state: Optional[Dict[str, Any]] = None
    limit: int = 6

WEIGHTS = {
    "product_view":1.0, "engaged_view":2.5, "component_click":2.0,
    "variety_click":2.5, "add_to_wishlist":4.0, "add_to_cart":6.0,
    "purchase":10.0, "remove_from_cart":-2.0, "remove_from_wishlist":-1.5
}
products = model["products"]
product_ids = model["product_ids"]
user_map = model["user_map"]
product_map = model["product_map"]
base_scores = model["hybrid_scores"]

@app.get("/health")
def health():
    return {"status":"ok","model":"YogaZen Hybrid Recommender"}

@app.post("/predict")
@app.post("/recommend")
def predict(req: PredictRequest):
    limit = max(1, min(int(req.limit), 20))
    uid = req.user_context.user_id
    if uid in user_map:
        scores = base_scores[user_map[uid]].astype(float).copy()
        reason_prefix = "Based on your previous activity"
    else:
        # Guest/new-user fallback: combine recent category and product affinities.
        scores = np.zeros(len(product_ids), dtype=float)
        recent_weights = {}
        for event in req.recent_interactions:
            weight = WEIGHTS.get(event.event_type or "product_view", 1.0)
            if event.event_type == "product_view" and (event.dwell_time_seconds or 0) >= 15:
                weight = 2.5
            if event.product_id in product_map:
                recent_weights[product_map[event.product_id]] = recent_weights.get(product_map[event.product_id], 0) + weight
        if recent_weights:
            sim = model["content_similarity"]
            total = sum(max(v,0) for v in recent_weights.values()) + 1e-8
            for idx, weight in recent_weights.items():
                scores += max(weight,0) * sim[idx] / total
            reason_prefix = "Based on your recent browsing"
        else:
            # Popularity fallback for completely new guests.
            scores = np.asarray(model["matrix"].sum(axis=0)).ravel().astype(float)
            reason_prefix = "Popular with YogaZen customers"
    excluded = set()
    if req.current_state:
        excluded.update(req.current_state.get("cart_items", []) or [])
        excluded.update(req.current_state.get("wishlist_items", []) or [])
    for event in req.recent_interactions:
        if event.product_id in product_map:
            # Avoid recommending the exact item just viewed; similar items remain eligible.
            excluded.add(event.product_id)
    for pid in excluded:
        if pid in product_map:
            scores[product_map[pid]] = -1e9
    top_idx = np.argsort(scores)[::-1]
    results = []
    for idx in top_idx:
        if scores[idx] < -1e8:
            continue
        row = products.iloc[idx]
        results.append({
            "product_id": str(row.product_id),
            "score": round(float(scores[idx]), 4),
            "reason": f"{reason_prefix}; matches {row.category}"
        })
        if len(results) >= limit:
            break
    return {"success":True, "user_id":uid, "recommendations":results}
