"""
YogaZen hybrid recommender training script.
Input: data/interactions_1000_customers.csv (or YogaZen exported CSV)
Output: models/yogazen_hybrid_model.joblib and outputs/evaluation_metrics.json
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import joblib
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
MODELS = ROOT / "models"
OUTPUTS = ROOT / "outputs"
MODELS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

interactions = pd.read_csv(DATA / "interactions_1000_customers.csv")
products = pd.read_csv(DATA / "products.csv")

required = {"user_id","product_id","product_title","category","interaction_score"}
missing = required - set(interactions.columns)
if missing:
    raise ValueError(f"Missing required columns: {sorted(missing)}")

# Aggregate duplicate user-product rows safely.
interactions = interactions.groupby(
    ["user_id","product_id","product_title","category"], as_index=False
).agg(interaction_score=("interaction_score","sum"))

user_ids = sorted(interactions.user_id.unique())
product_ids = products.product_id.tolist()
u_map = {v:i for i,v in enumerate(user_ids)}
p_map = {v:i for i,v in enumerate(product_ids)}
rows = interactions.user_id.map(u_map).to_numpy()
cols = interactions.product_id.map(p_map)
valid = cols.notna().to_numpy()
matrix = csr_matrix(
    (interactions.loc[valid,"interaction_score"].astype(float).to_numpy(),
     (rows[valid], cols[valid].astype(int).to_numpy())),
    shape=(len(user_ids),len(product_ids)), dtype=np.float32
)

components = min(32, max(2, min(matrix.shape)-1))
svd = TruncatedSVD(n_components=components, random_state=42, n_iter=10)
user_factors = svd.fit_transform(matrix)
item_factors = svd.components_.T
cf = np.maximum(user_factors @ item_factors.T, 0)

text = (products.product_title.fillna("") + " " +
        products.category.fillna("") + " " +
        products.get("description", pd.Series([""]*len(products))).fillna("")).tolist()
tfidf = TfidfVectorizer(ngram_range=(1,2), stop_words="english")
content = tfidf.fit_transform(text)
similarity = cosine_similarity(content)
user_content = np.zeros_like(cf)
for u in range(len(user_ids)):
    weights = np.maximum(matrix.getrow(u).toarray().ravel(), 0)
    if weights.sum():
        user_content[u] = (weights @ similarity) / weights.sum()

def minmax(x):
    lo, hi = x.min(axis=1, keepdims=True), x.max(axis=1, keepdims=True)
    return (x-lo)/(hi-lo+1e-8)

scores = .65*minmax(cf) + .35*minmax(user_content)
bundle = {
    "user_ids":user_ids, "product_ids":product_ids, "user_map":u_map,
    "product_map":p_map, "products":products, "matrix":matrix,
    "svd":svd, "tfidf":tfidf, "content_similarity":similarity,
    "hybrid_scores":scores, "cf_weight":.65, "content_weight":.35
}
joblib.dump(bundle, MODELS/"yogazen_hybrid_model.joblib", compress=3)
print(f"Trained on {len(user_ids)} customers and {len(product_ids)} products.")
print(f"Saved: {MODELS/'yogazen_hybrid_model.joblib'}")
